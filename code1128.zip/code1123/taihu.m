function dxdt=taihu(~,x,r1,r4,c2,c4,c5,p)
dxdt=zeros(2,1);
dxdt(1)=x(1)*(1-x(1))*(p*r1*x(2)-r1*x(2)+r4*x(2)-c2);
dxdt(2)=x(2)*(1-x(2))*(r1*x(1)-p*r1*x(1)+r4*x(1)-c4-c5);
end
