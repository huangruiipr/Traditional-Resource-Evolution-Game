clc;clear;clf;
r1=40;r4=30;c2=2;c4=5;c5=5;p=0.5;

figure(1)
for iii = 0.05:0.05:0.95
    for jjj = 0.05:0.05:0.95 
        [t,x]=ode45(@(t,x) taihu(t,x,r1,r4,c2,c4,c5,p),[0,20],[iii,jjj]); 
        plot(x(:,1),x(:,2),'k-'); 
        hold on
    end
end
hold on
set(gca,'XTick',0:0.1:1,'YTick',0:0.1:1)
axis([0 1 0 1])
xlabel('$x$', 'interpreter','latex');
ylabel('$y$','interpreter','latex', 'rotation',360);
title('动态演化过程');
legend('Initial Value[0.1,0.1]', 'Initial Value[0.3,0.3] ', 'Initial Value[0.5,0.6] ', 'Initial Value[0.7,0.8] ');



figure(2)
hold on
for r1=10:5:100
    [t,x]=ode45(@(t,x) taihu(t,x,r1,r4,c2,c4,c5,p),[0,200],[0.5,0.5]); 
    plot(t,x(:,1),'k-'); 
    plot(t,x(:,2),'r-'); 
    hold on
end
xlim([0,4])
ylim([0,1])


figure(3)
hold on
for r4=10:5:100
    [t,x]=ode45(@(t,x) taihu(t,x,r1,r4,c2,c4,c5,p),[0,200],[0.5,0.5]); 
    plot(t,x(:,1),'k-'); 
    plot(t,x(:,2),'r-'); 
    hold on
end
xlim([0,4])
ylim([0,1])

figure(4)
hold on
for c2=1:1:10
    [t,x]=ode45(@(t,x) taihu(t,x,r1,r4,c2,c4,c5,p),[0,200],[0.5,0.5]); 
    plot(t,x(:,1),'k-'); 
    plot(t,x(:,2),'r-'); 
    hold on
end
xlim([0,0.2])
ylim([0,1])

figure(5)
hold on
for c4=1:1:10
    [t,x]=ode45(@(t,x) taihu(t,x,r1,r4,c2,c4,c5,p),[0,200],[0.5,0.5]); 
    plot(t,x(:,1),'k-'); 
    plot(t,x(:,2),'r-'); 
    hold on
end
xlim([0,0.15])
ylim([0,1])

figure(6)
hold on
for c5=1:1:10
    [t,x]=ode45(@(t,x) taihu(t,x,r1,r4,c2,c4,c5,p),[0,200],[0.5,0.5]); 
    plot(t,x(:,1),'k-'); 
    plot(t,x(:,2),'r-'); 
    hold on
end
xlim([0,0.15])
ylim([0,1])